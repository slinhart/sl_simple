<html>
<head>
	<?php include('partials/head.php'); ?>
</head>
<body>
	Email: <?php echo $_POST['email']; ?> Text: <?php echo $_POST['message']; ?>
	<?php include('partials/primary_scripts.php'); ?>
</body>
</html>